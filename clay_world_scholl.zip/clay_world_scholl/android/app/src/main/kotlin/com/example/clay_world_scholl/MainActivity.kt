package com.example.clay_world_scholl

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
