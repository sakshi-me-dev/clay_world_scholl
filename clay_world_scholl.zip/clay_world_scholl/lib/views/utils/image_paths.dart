const appLogoPath = "assets/icons/app_icon.png";
