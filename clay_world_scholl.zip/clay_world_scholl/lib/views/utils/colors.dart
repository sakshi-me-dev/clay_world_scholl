import 'package:flutter/material.dart';

const buttonColor = Color(0xFFED1B24);
